export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: "sans-serif" }}>
      <h1>Atony AI</h1>
      <p>This is a brutally honest AI. Ask anything.</p>
    </div>
  );
}
