# Atony AI
This is the frontend for Atony AI - a brutally honest chatbot.